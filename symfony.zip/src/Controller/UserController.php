<?php

namespace App\Controller;

use App\Entity\User;
use App\Form\Type\UserType;
use App\Repository\NoteRepository;
use App\Repository\UserRepository;
use App\Utils\PasswordEncoder;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;


class UserController extends AbstractController
{

    /**
     * @required
     */
    public PasswordEncoder $passwordEncoder;
    /**
     * @required
     */
    public EntityManagerInterface $entityManager;

    /**
     * @required
     */
    public NoteRepository $noteRepository;
    /**
     * @required
     */
    public UserRepository $userRepository;

    public function register(Request $request)
    {
        $user = new User();
        $form = $this->createForm(UserType::class, $user);
        $form->handleRequest($request);
        if ($form->isSubmitted()) {
            // 3) Encode the password (you could also do this via Doctrine listener)
            $password = password_hash($form->getData()->getPassword(),PASSWORD_BCRYPT);
            $user->setPassword($password);

            // 4) save the User!
            $this->entityManager->persist($user);
            $this->entityManager->flush();

            // ... do any other work - like sending them an email, etc
            // maybe set a "flash" success message for the user

            return $this->redirectToRoute('login');
        }
        return $this->render('users/register.html.twig', ['form' => $form->createView()]);
    }

    public function login(Request $request)
    {
        $user = new User();
        $form = $this->createForm(UserType::class, $user);
        $form->handleRequest($request);
        if ($form->isSubmitted()) {
            /**
             * @var User $user
             */
            $user = $this->userRepository->findOneBy(['username' => $form->getData()->getUsername()]);
            if ($user) {

                if (password_verify($form->getData()->getPassword(),$user->getPassword())) {
                    $notes = $this->noteRepository->findBy(['user' => $user]);
                    return $this->render('users/profile.html.twig', ['user' => $user,'notes'=>$notes]);
                }
                $this->addFlash('error', 'wrong password');
                return $this->renderView('users/login.html.twig', ['form' => $form]);
            }
            $this->addFlash('error', 'user not found');
        }

        return $this->render('users/login.html.twig', ['form' => $form->createView()]);

    }

    public function profile()
    {

    }

    public function logout()
    {
        unset($_SESSION);
        return $this->redirectToRoute('login');
    }
}