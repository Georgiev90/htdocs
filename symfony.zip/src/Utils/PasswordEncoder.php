<?php

namespace App\Utils;

class PasswordEncoder
{
    public function encode(string $password)
    {
        for ($i = 0; $i<strlen($password);$i++) {
            $password[$i] = chr(ord($password[$i])+3);
        }
        return $password;
    }

    public function decode()
    {

    }
}